#!/usr/bin/env bash
# =============================================================================
# MLPerf v6.0 Stage6 — 전자동 실행 (MPI 우회 자동 탐색 → 벤치마크 → 요약)
#
#   bash mlperf-stage6.sh              1 GPU test_run (검증)
#   bash mlperf-stage6.sh 7            7 GPU test_run
#   bash mlperf-stage6.sh 7 full       7 GPU 풀런 (40분)
#
# 화면 출력은 최소입니다. 마지막 요약 블록만 사진 찍으시면 됩니다.
# 상세 로그는 전부 파일로 빠집니다 (반출 불필요).
# =============================================================================

BASE="${BASE:-/data/lsh}"
REPO="$BASE/inference_results_v6.0/closed/NVIDIA"
SCRATCH="${MLPERF_SCRATCH_PATH:-$BASE/mlperf_inference_storage}"
SQSH="$REPO/build/sqsh_images/mlperf-inference-$(whoami)-x86_64-release.sqsh"
RUNDIR="$BASE/mlperf-runs"; mkdir -p "$RUNDIR"
TS=$(date +%m%d-%H%M)
V="$RUNDIR/verbose-$TS.log"          # 상세 로그 (화면에 안 나옴)

NG="${1:-1}"
[ "$2" = "full" ] && TESTRUN="" || TESTRUN="--test_run"
[ -n "$TESTRUN" ] && WALL="02:00:00" || WALL="03:00:00"

PUB=112954                            # 공개값 8GPU Offline Tokens/s
TARGET=$(( PUB * NG / 8 ))

# 죽은 allocation 잔재 제거 (이게 없으면 srun이 만료된 잡에 붙으려다 실패)
unset SLURM_JOB_ID SLURM_JOBID SLURM_NODELIST SLURM_NTASKS SLURM_JOB_NODELIST

say() { printf '%s\n' "$*"; }
log() { echo "=== $(date +%T) $* ===" >> "$V"; }

say "MLPerf v6.0 자동 실행  |  GPU ${NG}장  |  $([ -n "$TESTRUN" ] && echo test_run || echo 풀런)"
say "상세로그: $V"
say ""

# =============================================================================
say "[1/5] 환경 정리"
scancel -u "$(whoami)" >>"$V" 2>&1
sleep 3
pkill -9 -f 'trtllm-serve|trtllm-llmapi|code.main' >>"$V" 2>&1
sleep 2
if sinfo -h -o '%t' | grep -qiE 'drain|down'; then
  sudo scontrol update NodeName="$(hostname -s)" State=RESUME >>"$V" 2>&1 \
    && say "   노드 RESUME 완료" || say "   노드 RESUME 실패 (sudo 필요)"
fi
NSTATE=$(sinfo -h -o '%t' | head -1)
BUSY=$(nvidia-smi --query-compute-apps=pid --format=csv,noheader | wc -l)
say "   노드=$NSTATE  GPU잔여프로세스=$BUSY"

# =============================================================================
say ""
say "[2/5] MPI 방식 자동 탐색 (각 30초 이내)"
PROBE='python3 -c "from mpi4py import MPI; print(\"MPIOK\", MPI.COMM_WORLD.Get_size())"'
MPIOPT=""
for m in none pmi2 pmix; do
  log "probe --mpi=$m"
  OUT=$(timeout 120 srun --nodes=1 --gres=gpu:1 --time=00:03:00 \
        --overlap --cpu-bind=none --mpi="$m" \
        --container-image "$SQSH" \
        bash -lc "$PROBE" 2>&1)
  echo "$OUT" >> "$V"
  if echo "$OUT" | grep -q 'MPIOK'; then
    say "   --mpi=$m  → OK"
    MPIOPT="$m"; break
  else
    say "   --mpi=$m  → 실패"
  fi
done
if [ -z "$MPIOPT" ]; then
  say ""
  say "  세 방식 모두 실패. 상세로그의 probe 구간 확인 필요."
  grep -A3 'OPAL ERROR\|MPI_Init' "$V" | tail -12
  exit 1
fi

# =============================================================================
say ""
say "[3/5] x${NG} config 확인"
CFG="$REPO/configs/B300-SXM-270GBx${NG}/Offline/llama2-70b.py"
if [ ! -f "$CFG" ]; then
  C8="$REPO/configs/B300-SXM-270GBx8"
  mkdir -p "$(dirname "$CFG")" "$REPO/configs/B300-SXM-270GBx${NG}/Server"
  Q=$(( 55 * NG )); S=$(( 400 * NG / 8 ))
  sed "s/offline_expected_qps: 440/offline_expected_qps: $Q/" "$C8/Offline/llama2-70b.py" > "$CFG"
  sed "s/server_target_qps: 400/server_target_qps: $S/" "$C8/Server/llama2-70b.py" \
      > "$REPO/configs/B300-SXM-270GBx${NG}/Server/llama2-70b.py"
  say "   생성 완료 (offline_expected_qps=$Q)"
else
  say "   기존 사용"
fi

# =============================================================================
say ""
say "[4/5] 벤치마크 실행 — 진행상황만 표시합니다"
say "   서버 기동 5~15분 + CUDA graph 캡처. 중간에 끊지 마세요."
say ""

# 백그라운드 모니터: GPU 최대 메모리 기록
PEAK="$RUNDIR/peak-$TS"; echo 0 > "$PEAK"
( while true; do
    m=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits | sort -rn | head -1)
    p=$(cat "$PEAK" 2>/dev/null || echo 0)
    [ "${m:-0}" -gt "${p:-0}" ] 2>/dev/null && echo "$m" > "$PEAK"
    sleep 15
  done ) & MON=$!
trap "kill $MON 2>/dev/null" EXIT

export SLURM_MPI_TYPE="$MPIOPT"
cd "$REPO" || exit 1

salloc --nodes=1 --gres=gpu:"$NG" --exclusive --time="$WALL" \
  ./scaleout/run_scaleout.sh \
    --stage all \
    --atomic-system B300-SXM-270GBx1 \
    --gpus-per-node "$NG" \
    --dp-multiplicity "$NG" \
    --container-image "$SQSH" \
    --mlperf-scratch-path "$SCRATCH" \
    --extra-srun-flags "--overlap --cpu-bind=none --mpi=$MPIOPT" \
    --server-spawn-time 30 \
    --run-args "--benchmarks=llama2-70b --scenarios=Offline --core_type=trtllm_endpoint $TESTRUN --readiness_timeout=1800" \
  >> "$V" 2>&1 &
RUNPID=$!

# 진행 표시 (60초마다 한 줄)
while kill -0 $RUNPID 2>/dev/null; do
  sleep 60
  D=$(ls -1dt "$REPO"/build/logs/scaleout_* 2>/dev/null | head -1)
  SL=0; [ -n "$D" ] && SL=$(cat "$D"/trtllm_serve_dp*_rank0.log 2>/dev/null | wc -l)
  GM=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits | sort -rn | head -1)
  say "   $(date +%H:%M)  서버로그 ${SL}줄   GPU최대 ${GM}MiB"
done
wait $RUNPID; RC=$?
kill $MON 2>/dev/null

# =============================================================================
D=$(ls -1dt "$REPO"/build/logs/scaleout_* 2>/dev/null | head -1)
SRV=$(ls -1 "$D"/trtllm_serve_dp0_rank0.log 2>/dev/null | head -1)
SUM=$(find "$D" -name mlperf_log_summary.txt 2>/dev/null | head -1)

MPIERR=0; SRVLINES=0; SRVUP=NO
if [ -n "$SRV" ]; then
  MPIERR=$(grep -c 'OPAL ERROR\|Local abort' "$SRV")
  SRVLINES=$(wc -l < "$SRV")
  grep -qi 'Uvicorn running\|Application startup complete' "$SRV" && SRVUP=YES
fi
GPEAK=$(cat "$PEAK" 2>/dev/null || echo 0)

TPS=""; VALID=""; PCT=""
if [ -n "$SUM" ]; then
  VALID=$(grep -m1 'Result is' "$SUM" | awk -F': *' '{print $2}')
  TPS=$(grep -m1 -E 'Completed tokens per second|Tokens per second' "$SUM" \
        | grep -oE '[0-9]+\.?[0-9]*' | head -1)
  [ -n "$TPS" ] && PCT=$(awk -v a="$TPS" -v b="$TARGET" 'BEGIN{printf "%.1f", a/b*100}')
fi

if   [ -n "$TPS" ]; then VERDICT="PASS"
elif [ "$SRVUP" = YES ]; then VERDICT="SERVER_OK_HARNESS_FAIL"
elif [ "$GPEAK" -gt 50000 ] 2>/dev/null; then VERDICT="MODEL_LOADED_SERVER_FAIL"
elif [ "$MPIERR" -gt 0 ]; then VERDICT="MPI_FAIL"
else VERDICT="SERVER_NEVER_STARTED"; fi

# =============================================================================
say ""
say "=================================================="
say " MLPerf v6.0  llama2-70b Offline   GPU ${NG}장"
say "=================================================="
printf " %-11s %s\n" "MPI"      "--mpi=$MPIOPT"
printf " %-11s %s\n" "MPI ERR"  "$MPIERR"
printf " %-11s %s\n" "SRV LOG"  "${SRVLINES}줄"
printf " %-11s %s\n" "SERVER UP" "$SRVUP"
printf " %-11s %s\n" "GPU PEAK" "${GPEAK} MiB"
printf " %-11s %s\n" "EXIT"     "$RC"
say "--------------------------------------------------"
if [ -n "$TPS" ]; then
printf " %-11s %s\n" "TOKENS/S" "$TPS"
printf " %-11s %s\n" "TARGET"   "$TARGET"
printf " %-11s %s\n" "달성률"    "${PCT}%"
printf " %-11s %s\n" "LOADGEN"  "$VALID"
fi
printf " %-11s %s\n" "VERDICT"  "$VERDICT"
say "=================================================="
say " CODE: V6.L2.G${NG}.${MPIOPT}.${VERDICT}.${TPS:-0}.${PCT:-0}"
say "=================================================="
say ""
if [ "$VERDICT" != "PASS" ]; then
  say "실패 지점 (마지막 8줄):"
  [ -n "$SRV" ] && grep -inE 'error|abort|traceback|out of memory|refused' "$SRV" | tail -8
fi
say "상세로그: $V"
