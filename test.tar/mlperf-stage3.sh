#!/usr/bin/env bash
# =============================================================================
# MLPerf Inference v6.0 Stage3 — llama2-70b 데이터셋/모델 확보 + 전처리
#
#   bash mlperf-stage3.sh              토크나이저만 받음 (권장, ~1GB)
#   FULL=1 bash mlperf-stage3.sh       원본 fp16 모델 전체까지 (~130GB)
#
# 선행: hf 로그인 + 아래 두 곳 라이선스 동의
#   - huggingface.co/meta-llama/Llama-2-70b-chat-hf
#   - huggingface.co/centml/llama2-70b-chat-hf-torch-fp4_mlperf-inf-v6.0
# =============================================================================

BASE="${BASE:-/data/lsh}"
REPO_DIR="$BASE/inference_results_v6.0/closed/NVIDIA"
SCRATCH="${MLPERF_SCRATCH_PATH:-$BASE/mlperf_inference_storage}"
SQSH="$REPO_DIR/build/sqsh_images/mlperf-inference-$(whoami)-x86_64-release.sqsh"
FULL="${FULL:-0}"

DATA_DIR="$SCRATCH/data/llama2-70b"
MODEL_DIR="$SCRATCH/models/Llama2/Llama-2-70b-chat-hf"
FP4_DIR="$SCRATCH/models/Llama2/fp4-quantized-modelopt/llama2-70b-chat-hf-torch-fp4"
mkdir -p "$DATA_DIR" "$MODEL_DIR" "$FP4_DIR" "$SCRATCH/preprocessed_data"

LOG="/tmp/mlperf-stage3-$(date +%Y%m%d-%H%M%S).log"
exec > >(tee -a "$LOG") 2>&1
step(){ echo; echo "===== $* ====="; }
S=()

echo "SCRATCH=$SCRATCH   FULL=$FULL"
echo "로그: $LOG"

# =============================================================================
step "1. HuggingFace 인증 / 게이트 접근 확인"
command -v hf >/dev/null || pip install -q -U "huggingface_hub[cli]" 2>&1 | tail -2
WHO=$(hf auth whoami 2>&1 | head -2)
echo "$WHO"
if echo "$WHO" | grep -qi 'not logged in\|error'; then
  echo
  echo "  ▶ 로그인 필요:  hf auth login   (WRITE 아닌 READ 토큰이면 충분)"
  S+=("HF: 미로그인 — 중단")
  printf '  %s\n' "${S[@]}"; exit 1
fi

gate() {
  if hf download "$1" config.json --quiet >/dev/null 2>&1 \
  || hf download "$1" --include 'config.json' --quiet >/dev/null 2>&1; then
    echo "  OK   $1"; return 0
  else
    echo "  차단 $1  ← 해당 페이지에서 라이선스 동의 필요"; return 1
  fi
}
gate meta-llama/Llama-2-70b-chat-hf && G_META=1 || G_META=0
gate centml/llama2-70b-chat-hf-torch-fp4_mlperf-inf-v6.0 && G_FP4=1 || G_FP4=0

# =============================================================================
step "2. OpenOrca 전처리 데이터셋 (MLCommons R2)"
cd "$DATA_DIR" || exit 1
R2="https://raw.githubusercontent.com/mlcommons/r2-downloader/refs/heads/main/mlc-r2-downloader.sh"

if ls "$DATA_DIR"/*sampled_24576* >/dev/null 2>&1; then
  echo "  validation 이미 존재"
else
  echo "  validation 다운로드..."
  bash <(curl -s "$R2") https://inference.mlcommons-storage.org/metadata/llama-2-70b-open-orca-dataset.uri
fi

if ls "$DATA_DIR"/*calibration_1000* >/dev/null 2>&1; then
  echo "  calibration 이미 존재"
else
  echo "  calibration 다운로드 (MLCFlow 경유)..."
  command -v mlcr >/dev/null || pip install -q -U mlc-scripts 2>&1 | tail -2
  mlcr get,dataset,preprocessed,openorca,_calibration,_r2-downloader,_mlc \
       --outdirname="$DATA_DIR" -j 2>&1 | tail -20 \
    || echo "  ▶ 실패 시 수동: mlcr 로그 확인 또는 MLCommons 회원 포털에서 calibration_1000.pkl 직접 반입"
fi

# 압축 해제 및 평탄화
find "$DATA_DIR" -name '*.pkl.gz' -exec gzip -dkf {} \; 2>/dev/null
find "$DATA_DIR" -mindepth 2 -name 'open_orca_gpt4_tokenized_llama.*.pkl' \
     -exec mv -n {} "$DATA_DIR/" \; 2>/dev/null
echo "  현재 파일:"
ls -lh "$DATA_DIR"/*.pkl 2>/dev/null || echo "   (pkl 없음)"

V_OK=$(ls "$DATA_DIR"/open_orca_gpt4_tokenized_llama.sampled_24576.pkl 2>/dev/null | wc -l)
C_OK=$(ls "$DATA_DIR"/open_orca_gpt4_tokenized_llama.calibration_1000.pkl 2>/dev/null | wc -l)
S+=("DATASET: validation=$V_OK calibration=$C_OK")

# =============================================================================
step "3. 모델 다운로드"
if [ "$G_META" -eq 1 ]; then
  if [ "$FULL" = "1" ]; then
    echo "  원본 fp16 전체 (~130GB)..."
    hf download meta-llama/Llama-2-70b-chat-hf --local-dir "$MODEL_DIR"
  else
    echo "  토크나이저/설정만 (~1GB). 전처리에 모델 가중치는 불필요합니다."
    hf download meta-llama/Llama-2-70b-chat-hf --local-dir "$MODEL_DIR" \
      --include 'config.json' 'tokenizer*' 'special_tokens_map.json' 'generation_config.json'
  fi
  ls -1 "$MODEL_DIR" | head
else
  echo "  건너뜀 (게이트 미승인)"
fi

if [ "$G_FP4" -eq 1 ]; then
  echo "  FP4 체크포인트 (~40GB)..."
  hf download centml/llama2-70b-chat-hf-torch-fp4_mlperf-inf-v6.0 --local-dir "$FP4_DIR"
  du -sh "$FP4_DIR" 2>/dev/null
else
  echo "  FP4 건너뜀 (게이트 미승인) — 하네스 실행에 필수입니다."
fi
S+=("MODEL: meta=$G_META fp4=$G_FP4")

# =============================================================================
step "4. 전처리 (컨테이너 내부 실행)"
if [ "$V_OK" -eq 1 ] && [ -f "$SQSH" ]; then
  echo "  salloc + srun 으로 컨테이너에서 실행합니다."
  cd "$REPO_DIR" || exit 1
  salloc --nodes=1 --gres=gpu:1 --time=01:30:00 srun \
    --container-image "$SQSH" \
    --container-mounts "$REPO_DIR:/work,$SCRATCH:/home/mlperf_inference_storage" \
    --container-workdir /work \
    --container-remap-root \
    --export ALL,MLPERF_SCRATCH_PATH=/home/mlperf_inference_storage \
    bash -lc '
      set -e
      make link_dirs
      ls -l build/
      python3 code/llama2-70b/tensorrt/preprocess_data.py \
        --data_dir build/data/ \
        --preprocessed_data_dir build/preprocessed_data
    ' 2>&1 | tail -40
else
  echo "  건너뜀 (데이터셋 또는 sqsh 미비)"
fi

# =============================================================================
step "5. 최종 검증"
P="$SCRATCH/preprocessed_data/llama2-70b"
for f in input_lens.npy input_ids_padded.npy \
         mlperf_llama2_openorca_calibration_1k/data.parquet; do
  [ -e "$P/$f" ] && echo "  OK   $f ($(du -h "$P/$f" 2>/dev/null | cut -f1))" \
                 || echo "  MISS $f"
done
READY=$([ -f "$P/input_ids_padded.npy" ] && echo 1 || echo 0)
S+=("PREPROCESS: $([ "$READY" = 1 ] && echo 완료 || echo 미완)")
df -h "$SCRATCH" | tail -1

step "요약"
printf '  %s\n' "${S[@]}"
echo
if [ "$READY" = "1" ]; then
cat <<EOC
--------------------- 본 실행 ---------------------
salloc --nodes=1 --gres=gpu:7 --exclusive --time=04:00:00

cd $REPO_DIR && ./scaleout/run_scaleout.sh \\
    --stage all --atomic-system B300-SXM-270GBx1 \\
    --gpus-per-node 7 --dp-multiplicity 7 \\
    --container-image $SQSH \\
    --mlperf-scratch-path $SCRATCH \\
    --extra-srun-flags "--overlap --cpu-bind=none" \\
    --run-args "--benchmarks=llama2-70b --scenarios=Offline --core_type=trtllm_endpoint --test_run"

# 먼저 --test_run(1분)으로 파이프라인 확인 → 정상이면 --test_run 빼고 풀런(40분)
# 목표: Offline 98833 Tokens/s 부근
EOC
else
  echo "  전처리 미완 — 위 MISS 항목과 4단계 로그 확인"
fi
echo
echo "로그: $LOG"
