#!/usr/bin/env bash
# =============================================================================
# MLPerf Inference v6.0 Stage2 — repo 확보 + x7 config + NGC sqsh 이미지
# XE9780 / HGX B300 7-GPU
#
#   bash mlperf-stage2.sh
#
# NGC 접근이 가능한 상태를 전제합니다.
# TensorRT-LLM 소스 빌드는 하지 않습니다 (NGC 완성 이미지 사용).
# =============================================================================

BASE="${BASE:-/data/lsh}"
REPO_ROOT="$BASE/inference_results_v6.0"
REPO_DIR="$REPO_ROOT/closed/NVIDIA"
SCRATCH="${MLPERF_SCRATCH_PATH:-$BASE/mlperf_inference_storage}"
NGC_IMG="nvcr.io/nvidia/mlperf/mlperf-inference:tensorrt_llm_release-feat-1.2-mlpinf-b5ddff4_mlperf-main-f538816_jan28_x86"
SQSH="$REPO_DIR/build/sqsh_images/mlperf-inference-$(whoami)-x86_64-release.sqsh"

# 대용량 임시파일이 /tmp(tmpfs)를 채우지 않도록 강제
export ENROOT_TEMP_PATH="${ENROOT_TEMP_PATH:-$BASE/.enroot/tmp}"
export ENROOT_CACHE_PATH="${ENROOT_CACHE_PATH:-$BASE/.enroot/cache}"
export ENROOT_DATA_PATH="${ENROOT_DATA_PATH:-$BASE/.enroot/data}"
mkdir -p "$ENROOT_TEMP_PATH" "$ENROOT_CACHE_PATH" "$ENROOT_DATA_PATH"

LOG="/tmp/mlperf-stage2-$(date +%Y%m%d-%H%M%S).log"
exec > >(tee -a "$LOG") 2>&1
step() { echo; echo "===== $* ====="; }
S=()   # 요약

echo "BASE=$BASE  SCRATCH=$SCRATCH"
echo "로그: $LOG"

# =============================================================================
step "1. 연결성 확인"
probe() {
  c=$(curl -sS -o /dev/null -w '%{http_code}' --max-time 12 "$2" 2>/dev/null)
  if [ -n "$c" ] && [ "$c" != "000" ]; then echo "  OK   $1 (HTTP $c)"; return 0
  else echo "  FAIL $1 — 도달 불가"; return 1; fi
}
probe "nvcr.io   (컨테이너)" https://nvcr.io/v2/          && N_NGC=1 || N_NGC=0
probe "github.com (repo)"    https://github.com           && N_GH=1  || N_GH=0
probe "huggingface (모델)"   https://huggingface.co       && N_HF=1  || N_HF=0

# =============================================================================
step "2. repo 확보"
if [ -d "$REPO_DIR/configs/B300-SXM-270GBx8" ]; then
  echo "  이미 존재: $REPO_DIR"
  S+=("REPO: 기존 사용")
elif [ "$N_GH" -eq 1 ]; then
  echo "  clone 시작 (closed/NVIDIA 만 sparse checkout)"
  rm -rf "$REPO_ROOT.partial"
  git clone --depth 1 --filter=blob:none --sparse \
      https://github.com/mlcommons/inference_results_v6.0.git "$REPO_ROOT.partial" \
    && ( cd "$REPO_ROOT.partial" && git sparse-checkout set closed/NVIDIA ) \
    && rm -rf "$REPO_ROOT" && mv "$REPO_ROOT.partial" "$REPO_ROOT" \
    && { echo "  clone 완료"; S+=("REPO: clone 완료"); } \
    || { echo "  clone 실패"; S+=("REPO: 실패"); }
else
  echo "  github 도달 불가 — repo를 수동 반입해야 합니다."
  S+=("REPO: 수동반입 필요")
fi
[ -d "$REPO_DIR" ] && du -sh "$REPO_ROOT" 2>/dev/null

# =============================================================================
step "3. 3rdparty 의존성"
if [ -d "$REPO_DIR" ] && [ "$N_GH" -eq 1 ]; then
  mkdir -p "$REPO_DIR/3rdparty"
  [ -d "$REPO_DIR/3rdparty/trtllm/.git" ] \
    || git clone --depth 1 https://github.com/NVIDIA/TensorRT-LLM.git "$REPO_DIR/3rdparty/trtllm"
  [ -d "$REPO_DIR/3rdparty/mlc-inference/.git" ] \
    || git clone --depth 1 https://github.com/mlcommons/inference.git "$REPO_DIR/3rdparty/mlc-inference"
  ls -1 "$REPO_DIR/3rdparty"
  S+=("3RDPARTY: $(ls -1 "$REPO_DIR/3rdparty" 2>/dev/null | wc -l)개")
else
  echo "  건너뜀"
fi

# =============================================================================
step "4. B300-SXM-270GBx7 harness config 생성"
C8="$REPO_DIR/configs/B300-SXM-270GBx8"
C7="$REPO_DIR/configs/B300-SXM-270GBx7"
if [ -d "$C8" ]; then
  mkdir -p "$C7/Offline" "$C7/Server"
  sed 's/offline_expected_qps: 440/offline_expected_qps: 385/' \
      "$C8/Offline/llama2-70b.py" > "$C7/Offline/llama2-70b.py"
  sed 's/server_target_qps: 400/server_target_qps: 350/' \
      "$C8/Server/llama2-70b.py"  > "$C7/Server/llama2-70b.py"
  grep -H -E 'offline_expected_qps|server_target_qps' "$C7"/*/llama2-70b.py
  S+=("CFG: x7 생성완료")
else
  echo "  $C8 없음 — repo 확보 후 재실행"
  S+=("CFG: 대기")
fi

# =============================================================================
step "5. NGC sqsh 이미지 import (TRT-LLM 소스빌드 없음)"
echo "  대상: $NGC_IMG"
echo "  출력: $SQSH"
echo "  임시경로: $ENROOT_TEMP_PATH (여유 $(df -BG --output=avail "$BASE" 2>/dev/null | tail -1 | tr -d ' '))"
mkdir -p "$(dirname "$SQSH")"
if [ -f "$SQSH" ]; then
  echo "  이미 존재 ($(du -h "$SQSH" | cut -f1)) — 건너뜀"
  S+=("SQSH: 기존 사용")
elif [ "$N_NGC" -eq 1 ]; then
  echo "  import 시작 — 30GB 내외, 20~60분 소요됩니다."
  if enroot import -o "$SQSH" "docker://nvcr.io#${NGC_IMG#nvcr.io/}"; then
    echo "  완료: $(du -h "$SQSH" | cut -f1)"
    S+=("SQSH: import 완료")
  else
    echo "  import 실패 — credential 확인: ~/.config/enroot/.credentials"
    S+=("SQSH: 실패")
  fi
else
  echo "  nvcr.io 도달 불가 — 건너뜀"
  S+=("SQSH: 대기")
fi

# =============================================================================
step "6. 데이터셋/모델 다운로드 안내 (MLCommons 원문)"
MLC="$REPO_DIR/3rdparty/mlc-inference/language/llama2-70b/README.md"
if [ -f "$MLC" ]; then
  echo "--- MLCommons llama2-70b README: 데이터셋 섹션 ---"
  sed -n '/[Gg]et [Dd]ataset/,/^## /p' "$MLC" | head -60
  echo
  echo "  (전문: $MLC)"
else
  echo "  mlc-inference 미확보 — 3단계 완료 후 확인 가능"
fi
echo
echo "  필요 자산:"
echo "   a) OpenOrca pkl 2개 (MLCommons R2, 위 README 절차)"
echo "   b) FP4 체크포인트: huggingface.co/centml/llama2-70b-chat-hf-torch-fp4_mlperf-inf-v6.0 (동의 필요)"
echo "   c) 원본 모델: meta-llama/Llama-2-70b-chat-hf (Meta 라이선스 동의 필요)"
if [ "$N_HF" -eq 1 ]; then
  echo "  huggingface 도달 가능. 로그인 상태:"
  huggingface-cli whoami 2>&1 | head -3 || echo "   huggingface-cli 미설치 (pip install -U 'huggingface_hub[cli]')"
else
  echo "  huggingface 도달 불가 — 체크포인트는 외부에서 반입 필요"
fi
mkdir -p "$SCRATCH"/{data,models,preprocessed_data}

# =============================================================================
step "요약"
printf '  %s\n' "${S[@]}"
echo
echo "--------------------- 다음 실행 커맨드 ---------------------"
cat <<EOC
# 주의: run_scaleout.sh 307행이 docker_tag를 aarch64로 하드코딩하고 있어
#       x86 환경에서는 --container-image 를 반드시 명시해야 합니다.

salloc --nodes=1 --gres=gpu:7 --exclusive --time=04:00:00

cd $REPO_DIR && ./scaleout/run_scaleout.sh \\
    --stage all --atomic-system B300-SXM-270GBx1 \\
    --gpus-per-node 7 --dp-multiplicity 7 \\
    --container-image $SQSH \\
    --mlperf-scratch-path $SCRATCH \\
    --extra-srun-flags "--overlap --cpu-bind=none" \\
    --run-args "--benchmarks=llama2-70b --scenarios=Offline --core_type=trtllm_endpoint --test_run"

# 목표: Offline 98833 Tokens/s 부근 (공개값 112954 x 7/8)
EOC
echo
echo "로그: $LOG"
