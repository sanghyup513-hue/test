#!/usr/bin/env bash
# =============================================================================
# MLPerf v6.0 — 처음부터 다시 (repo 재구축)
#
#   bash mlperf-reset.sh
#
# 보존하는 것 (다시 받으면 몇 시간 걸리는 자산):
#   - $SCRATCH/models        FP4 체크포인트 37GB
#   - $SCRATCH/data          OpenOrca pkl
#   - $SCRATCH/preprocessed_data
#   - sqsh 컨테이너 이미지 30GB   ← repo 밖으로 대피 후 복구
#
# 삭제/재생성:
#   - inference_results_v6.0 repo 전체
#
# 재적용하는 검증된 수정 3가지:
#   1) loadgen.py 버전 고정 (v6.1 KeyError 회피)
#   2) run_scaleout.sh mpi_mode leader -> legacy (대입부만, 조건절 보존)
#   3) B300-SXM-270GBx7 config 생성
# =============================================================================
set -u

BASE="${BASE:-/data/lsh}"
REPO_ROOT="$BASE/inference_results_v6.0"
REPO="$REPO_ROOT/closed/NVIDIA"
SCRATCH="${MLPERF_SCRATCH_PATH:-$BASE/mlperf_inference_storage}"
SAFE="$BASE/preserved"
V="$BASE/reset-$(date +%m%d-%H%M).log"

say(){ printf '%s\n' "$*"; }
ok(){ printf '   OK   %s\n' "$*"; }
ng(){ printf '   FAIL %s\n' "$*"; }

say "MLPerf v6.0 재구축"
say "로그: $V"
say ""

# =============================================================================
say "[1/8] 실행 중인 것 정리"
scancel -u "$(whoami)" >>"$V" 2>&1; sleep 3
pkill -9 -f 'trtllm-serve|trtllm-llmapi|code.main|run_scaleout' >>"$V" 2>&1; sleep 2
sinfo -h -o '%t' | grep -qiE 'drain|down' && \
  sudo scontrol update NodeName="$(hostname -s)" State=RESUME >>"$V" 2>&1
unset SLURM_JOB_ID SLURM_JOBID SLURM_NODELIST SLURM_NTASKS SLURM_JOB_NODELIST
ok "노드=$(sinfo -h -o '%t' | head -1)  GPU프로세스=$(nvidia-smi --query-compute-apps=pid --format=csv,noheader | wc -l)"

# =============================================================================
say ""
say "[2/8] 보존 자산 확인 및 대피"
mkdir -p "$SAFE"
for d in models data preprocessed_data; do
  if [ -d "$SCRATCH/$d" ]; then ok "$SCRATCH/$d  ($(du -sh "$SCRATCH/$d" 2>/dev/null | cut -f1))"
  else ng "$SCRATCH/$d 없음"; fi
done
SQSH_SRC=$(ls -1 "$REPO"/build/sqsh_images/*.sqsh 2>/dev/null | head -1)
if [ -n "$SQSH_SRC" ]; then
  mv "$SQSH_SRC" "$SAFE/" && ok "sqsh 대피: $SAFE/$(basename "$SQSH_SRC") ($(du -h "$SAFE/$(basename "$SQSH_SRC")" | cut -f1))"
elif ls "$SAFE"/*.sqsh >/dev/null 2>&1; then
  ok "sqsh 이미 대피됨: $(ls -1 "$SAFE"/*.sqsh | head -1)"
else
  ng "sqsh 이미지를 못 찾음 — 재구축 후 다시 import 필요"
fi

# =============================================================================
say ""
say "[3/8] repo 삭제"
rm -rf "$REPO_ROOT" && ok "삭제 완료" || ng "삭제 실패"

# =============================================================================
say ""
say "[4/8] repo clone (closed/NVIDIA 만)"
git clone --depth 1 --filter=blob:none --sparse \
    https://github.com/mlcommons/inference_results_v6.0.git "$REPO_ROOT" >>"$V" 2>&1 \
  && ( cd "$REPO_ROOT" && git sparse-checkout set closed/NVIDIA >>"$V" 2>&1 ) \
  && ok "$(du -sh "$REPO_ROOT" | cut -f1)" || { ng "clone 실패"; exit 1; }

# =============================================================================
say ""
say "[5/8] 3rdparty"
mkdir -p "$REPO/3rdparty"
git clone --depth 1 https://github.com/mlcommons/inference.git \
    "$REPO/3rdparty/mlc-inference" >>"$V" 2>&1 && ok "mlc-inference" || ng "mlc-inference"
git clone --depth 1 https://github.com/NVIDIA/TensorRT-LLM.git \
    "$REPO/3rdparty/trtllm" >>"$V" 2>&1 && ok "trtllm" || ng "trtllm"

# =============================================================================
say ""
say "[6/8] 검증된 수정 재적용"

# --- (1) loadgen.py 버전 고정 -----------------------------------------------
L="$REPO/code/common/mlcommons/loadgen.py"
cp "$L" "$L.orig"
sed -i 's|^_latest_ver = max(versioning.parse(ver_key) for ver_key in submission_checker_constants.MODEL_CONFIG.keys())|_latest_ver = versioning.parse(C.VERSION.lstrip("v"))|' "$L"
if grep -q '_latest_ver = versioning.parse(C.VERSION' "$L" && python3 -m py_compile "$L" 2>>"$V"; then
  ok "loadgen.py 버전 고정 (v6.0)"
else
  cp "$L.orig" "$L"; ng "loadgen.py 패치 실패 — 원복함"
fi

# --- (2) run_scaleout.sh mpi_mode: 대입부만 치환 -----------------------------
R="$REPO/scaleout/run_scaleout.sh"
cp "$R" "$R.orig"
sed -i 's|run_args="\$run_args --mpi_mode=leader"|run_args="$run_args --mpi_mode=legacy"|g' "$R"
if bash -n "$R" 2>>"$V" && grep -q 'mpi_mode=legacy' "$R"; then
  ok "mpi_mode -> legacy ($(grep -c 'mpi_mode=legacy' "$R")곳), 조건절 보존 확인:"
  grep -n 'mpi_mode\|server_in_foreground' "$R" | sed 's/^/        /'
else
  cp "$R.orig" "$R"; ng "run_scaleout.sh 패치 실패 — 원복함"
fi

# --- (3) x7 config -----------------------------------------------------------
C8="$REPO/configs/B300-SXM-270GBx8"
C7="$REPO/configs/B300-SXM-270GBx7"
mkdir -p "$C7/Offline" "$C7/Server"
sed 's/offline_expected_qps: 440/offline_expected_qps: 385/' "$C8/Offline/llama2-70b.py" > "$C7/Offline/llama2-70b.py"
sed 's/server_target_qps: 400/server_target_qps: 350/'       "$C8/Server/llama2-70b.py"  > "$C7/Server/llama2-70b.py"
[ -s "$C7/Offline/llama2-70b.py" ] && ok "x7 config 생성" || ng "x7 config 실패"

# =============================================================================
say ""
say "[7/8] sqsh 이미지 복구"
mkdir -p "$REPO/build/sqsh_images"
S=$(ls -1 "$SAFE"/*.sqsh 2>/dev/null | head -1)
if [ -n "$S" ]; then
  mv "$S" "$REPO/build/sqsh_images/" && ok "$(ls -1 "$REPO"/build/sqsh_images/*.sqsh | head -1)"
else
  ng "sqsh 없음 — 아래 명령으로 재생성 필요:"
  say "        export ENROOT_TEMP_PATH=$BASE/.enroot/tmp ENROOT_CACHE_PATH=$BASE/.enroot/cache"
  say "        enroot import -o $REPO/build/sqsh_images/mlperf-inference-$(whoami)-x86_64-release.sqsh \\"
  say "          docker://nvcr.io#nvidia/mlperf/mlperf-inference:tensorrt_llm_release-feat-1.2-mlpinf-b5ddff4_mlperf-main-f538816_jan28_x86"
fi

# =============================================================================
say ""
say "[8/8] 최종 확인"
N=0; F=0
chk(){ if eval "$2"; then ok "$1"; N=$((N+1)); else ng "$1"; F=$((F+1)); fi; }
chk "repo"              "[ -d '$REPO/configs/B300-SXM-270GBx8' ]"
chk "3rdparty 2개"      "[ \$(ls -1 '$REPO/3rdparty' | wc -l) -ge 2 ]"
chk "loadgen 버전고정"  "grep -q '_latest_ver = versioning.parse(C.VERSION' '$L'"
chk "mpi_mode=legacy"   "grep -q 'mpi_mode=legacy' '$R'"
chk "run_scaleout 문법" "bash -n '$R'"
chk "x7 config"         "[ -f '$C7/Offline/llama2-70b.py' ]"
chk "sqsh 이미지"       "ls '$REPO'/build/sqsh_images/*.sqsh >/dev/null 2>&1"
chk "FP4 체크포인트"    "[ -d '$SCRATCH/models/Llama2/fp4-quantized-modelopt/llama2-70b-chat-hf-torch-fp4' ]"
chk "전처리 데이터"     "[ -f '$SCRATCH/preprocessed_data/llama2-70b/input_ids_padded.npy' ]"

say ""
say "=================================================="
say " 재구축 결과   OK ${N} / FAIL ${F}"
say "=================================================="
if [ "$F" -eq 0 ]; then
  say " 다음 실행:"
  say "   bash ~/mlperf-stage6.sh        1 GPU 검증"
  say "   bash ~/mlperf-stage6.sh 7      7 GPU test_run"
else
  say " FAIL 항목 해결 후 재실행하세요."
fi
say " 로그: $V"
say "=================================================="
