#!/usr/bin/env bash
# =============================================================================
# MLPerf Inference v6.0 사전점검 — XE9780 / HGX B300 (7-GPU degraded)
#
# 사용법:
#   1) 아래 [설정] 값 3개만 환경에 맞게 수정
#   2) bash mlperf-precheck.sh
#   3) 생성된 tar.gz 하나만 회신
#
# 읽기 전용입니다. 시스템 상태를 변경하지 않습니다.
# =============================================================================

# ----------------------------- [설정] ----------------------------------------
REPO_DIR="${REPO_DIR:-/data/lsh/inference_results_v6.0/closed/NVIDIA}"
SCRATCH="${MLPERF_SCRATCH_PATH:-/data/lsh/mlperf_inference_storage}"
PARTITION="${PARTITION:-}"          # 비워두면 sinfo 기본 파티션 사용
# -----------------------------------------------------------------------------

TS=$(date +%Y%m%d-%H%M%S)
OUT="/tmp/mlperf-precheck-$(hostname -s)-${TS}"
mkdir -p "$OUT"
LOG="$OUT/report.txt"
exec > >(tee -a "$LOG") 2>&1

PASS=(); WARN=(); FAIL=()
ok()   { PASS+=("$1"); }
warn() { WARN+=("$1"); }
bad()  { FAIL+=("$1"); }

sec() { echo; echo "==================== $* ===================="; }
run() { echo "--- \$ $* ---"; eval "$@" 2>&1 || echo "[명령 실패: $*]"; echo; }

echo "MLPerf Inference v6.0 사전점검"
echo "호스트: $(hostname -f)   시각: $(date -Is)"
echo "REPO_DIR=$REPO_DIR"
echo "SCRATCH=$SCRATCH"

# =============================================================================
sec "1. 시스템 / 펌웨어"
run "cat /etc/os-release | head -3"
run "uname -a"
run "dmidecode -s system-product-name; dmidecode -s bios-version" 
run "free -g | head -2"

# =============================================================================
sec "2. CPU / NUMA (Server 시나리오 성능에 직결)"
run "lscpu | grep -Ei 'model name|socket|core|thread|numa'"
run "numactl -H"
run "cat /sys/kernel/mm/transparent_hugepage/enabled"
run "cpupower frequency-info 2>/dev/null | head -20"

# =============================================================================
sec "3. PCIe 열거 — GPU 물리 존재 확인"
run "lspci -d 10de: -nn"
GPU_PCI=$(lspci -d 10de: -nn 2>/dev/null | grep -ci '3d controller\|display controller' || echo 0)
echo "PCIe에서 보이는 NVIDIA GPU 디바이스 수: $GPU_PCI"
run "lspci -tv 2>/dev/null | grep -A2 -i nvidia | head -40"
echo "--- 루트 브리지 목록 (누락 슬롯 판별용) ---"
run "ls -1 /sys/devices/pci0000:* -d 2>/dev/null; ls -1 /sys/class/pci_bus/ 2>/dev/null"

# =============================================================================
sec "4. 드라이버 / Fabric Manager 패키지 버전 정합성"
run "nvidia-smi --version 2>/dev/null | head -10"
run "dpkg -l 2>/dev/null | grep -Ei 'nvidia-open|nvidia-driver|fabricmanager|nvlink5|nscq|nvsdm|nvidia-imex|dcgm' | awk '{print \$2, \$3}'"
run "systemctl is-active nvidia-fabricmanager; systemctl is-active nvidia-imex 2>/dev/null"
run "systemctl --no-pager status nvidia-fabricmanager 2>/dev/null | head -15"
run "journalctl -u nvidia-fabricmanager --no-pager -n 40 2>/dev/null"

# =============================================================================
sec "5. GPU 상태 / Fabric / NVLink"
run "nvidia-smi"
echo "--- GPU 인벤토리 + Fabric 상태 (핵심) ---"
run "nvidia-smi --format=csv --query-gpu=index,serial,uuid,pci.bus_id,name,memory.total,fabric.state,fabric.status,persistence_mode,ecc.mode.current"
run "nvidia-smi topo -m"
run "nvidia-smi nvlink -s"
run "nvidia-smi nvlink -e 2>/dev/null | head -60"
echo "--- 클럭 / 전력 / throttle 사유 (벤치 전 baseline) ---"
run "nvidia-smi --format=csv --query-gpu=index,clocks.sm,clocks.max.sm,power.draw,power.limit,power.max_limit,temperature.gpu,clocks_throttle_reasons.active"
echo "--- ECC / Row remap (RMA 증빙) ---"
run "nvidia-smi --format=csv --query-gpu=index,retired_pages.pending,remapped_rows.pending,remapped_rows.failure,ecc.errors.uncorrected.volatile.total"
run "nvidia-smi -q -d ROW_REMAPPER 2>/dev/null | grep -E 'GPU |Remapping Failure|Pending|Correctable|Uncorrectable'"

nvidia-smi -L > "$OUT/gpu-list.txt" 2>&1
GPU_N=$(grep -c '^GPU ' "$OUT/gpu-list.txt" 2>/dev/null || echo 0)
echo "드라이버가 인식한 GPU 수: $GPU_N"

FAB_BAD=$(nvidia-smi --format=csv,noheader --query-gpu=index,fabric.status 2>/dev/null \
          | grep -vic 'success' || echo 0)

# =============================================================================
sec "6. Xid / SXid 이력"
run "dmesg -T 2>/dev/null | grep -Ei 'xid|sxid|nvswitch|nvlink|nvidia' | tail -60"
run "journalctl -k --no-pager -b -1 2>/dev/null | grep -Ei 'xid|sxid' | tail -30"

# =============================================================================
sec "7. SLURM"
run "sinfo --version"
run "sinfo -o '%P %a %l %D %t %N %G'"
run "scontrol show node $(hostname -s) 2>/dev/null"
run "scontrol show partition 2>/dev/null | head -40"
run "scontrol show config 2>/dev/null | grep -Ei 'SelectType|GresTypes|MpiDefault|TaskPlugin|ProctrackType|JobAcctGather|MaxStepCount'"
run "cat /etc/slurm/gres.conf 2>/dev/null || cat /etc/slurm-llnl/gres.conf 2>/dev/null"
run "cat /etc/slurm/cgroup.conf 2>/dev/null || cat /etc/slurm-llnl/cgroup.conf 2>/dev/null"
run "srun --mpi=list 2>&1"
run "systemctl is-active slurmctld slurmd munge 2>/dev/null"

SLURM_GRES=$(scontrol show node "$(hostname -s)" 2>/dev/null | grep -oP 'Gres=gpu:\K[0-9]+' | head -1)
echo "slurm.conf Gres=gpu:${SLURM_GRES:-미확인}"

# =============================================================================
sec "8. Enroot / Pyxis"
run "enroot version"
run "enroot list 2>/dev/null"
run "cat /etc/enroot/enroot.conf 2>/dev/null | grep -v '^#' | grep -v '^$'"
run "ls -la /etc/enroot/hooks.d/ 2>/dev/null"
echo "--- NGC credentials 존재 여부 (내용은 출력하지 않음) ---"
for f in "$HOME/.config/enroot/.credentials" /etc/enroot/.credentials; do
  if [ -f "$f" ]; then echo "$f : 존재 ($(wc -l < "$f")줄, perm $(stat -c %a "$f"))"; else echo "$f : 없음"; fi
done
echo
run "cat /etc/slurm/plugstack.conf 2>/dev/null; cat /etc/slurm/plugstack.conf.d/*.conf 2>/dev/null"
run "srun --help 2>&1 | grep -i container | head -20"
run "sysctl kernel.apparmor_restrict_unprivileged_userns 2>/dev/null"

PYXIS_OK=$(srun --help 2>&1 | grep -ci 'container-image' || echo 0)

# =============================================================================
sec "9. MLPerf repo 상태"
if [ -d "$REPO_DIR" ]; then
  echo "REPO_DIR 존재"
  run "ls -1 $REPO_DIR"
  run "ls -1 $REPO_DIR/3rdparty 2>/dev/null"
  run "ls -1 $REPO_DIR/configs 2>/dev/null"
  echo "--- B300 관련 config 트리 ---"
  run "find $REPO_DIR/configs -maxdepth 3 -path '*B300*' -name '*.py' 2>/dev/null | sort"
  echo "--- 7-GPU harness config 존재 여부 (필수) ---"
  for s in Offline Server; do
    p="$REPO_DIR/configs/B300-SXM-270GBx7/$s/llama2-70b.py"
    [ -f "$p" ] && echo "$p : 존재" || echo "$p : 없음  <-- 생성 필요"
  done
  echo
  run "grep -nE 'offline_expected_qps|server_target_qps' $REPO_DIR/configs/B300-SXM-270GBx7/*/llama2-70b.py 2>/dev/null"
  run "ls -1 $REPO_DIR/build/sqsh_images/ 2>/dev/null"
  run "ls -1 $REPO_DIR/build/ 2>/dev/null"
else
  echo "REPO_DIR 없음: $REPO_DIR"
fi
X7_CFG=$([ -f "$REPO_DIR/configs/B300-SXM-270GBx7/Offline/llama2-70b.py" ] && echo 1 || echo 0)
SQSH_N=$(ls -1 "$REPO_DIR/build/sqsh_images/"*.sqsh 2>/dev/null | wc -l)

# =============================================================================
sec "10. Scratch space / 모델 / 데이터셋"
run "df -h $SCRATCH 2>/dev/null"
if [ -d "$SCRATCH" ]; then
  run "du -sh $SCRATCH/* 2>/dev/null"
  echo "--- llama2-70b 필수 산출물 ---"
  for f in \
    "$SCRATCH/preprocessed_data/llama2-70b/input_lens.npy" \
    "$SCRATCH/preprocessed_data/llama2-70b/input_ids_padded.npy" \
    "$SCRATCH/preprocessed_data/llama2-70b/mlperf_llama2_openorca_calibration_1k/data.parquet" ; do
    [ -e "$f" ] && echo "OK   $f ($(du -h "$f" 2>/dev/null | cut -f1))" || echo "MISS $f"
  done
  run "ls -1 $SCRATCH/models/Llama2/ 2>/dev/null; ls -1 $SCRATCH/models/llama2-70b/ 2>/dev/null"
  echo "--- deepseek-r1 필수 산출물 ---"
  for f in \
    "$SCRATCH/preprocessed_data/deepseek-r1/input_lens.npy" \
    "$SCRATCH/preprocessed_data/deepseek-r1/input_ids_padded.npy" ; do
    [ -e "$f" ] && echo "OK   $f ($(du -h "$f" 2>/dev/null | cut -f1))" || echo "MISS $f"
  done
  run "ls -1 $SCRATCH/models/deepseek-r1/ 2>/dev/null"
else
  echo "SCRATCH 경로 없음: $SCRATCH"
fi
L2_READY=$([ -f "$SCRATCH/preprocessed_data/llama2-70b/input_ids_padded.npy" ] && echo 1 || echo 0)
SCRATCH_FREE=$(df -BG --output=avail "$SCRATCH" 2>/dev/null | tail -1 | tr -dc '0-9')

# =============================================================================
sec "11. scaleout dry-run (실행 없이 srun 커맨드만 확인)"
if [ -x "$REPO_DIR/scaleout/run_scaleout.sh" ]; then
  PART_ARG=""
  [ -n "$PARTITION" ] && PART_ARG="--partition=$PARTITION"
  echo "salloc로 7 GPU 잡아서 dry-run 시도합니다 (즉시 종료)."
  ( cd "$REPO_DIR" && \
    timeout 180 salloc --nodes=1 $PART_ARG --gres=gpu:7 --exclusive --time=00:03:00 \
      ./scaleout/run_scaleout.sh \
        --stage all \
        --atomic-system B300-SXM-270GBx1 \
        --gpus-per-node 7 \
        --dp-multiplicity 7 \
        --mlperf-scratch-path "$SCRATCH" \
        --run-args "--benchmarks=llama2-70b --scenarios=Offline --core_type=trtllm_endpoint" \
        --dry-run 2>&1 ) || echo "[dry-run 실패 — 위 메시지 확인]"
else
  echo "run_scaleout.sh 없음 또는 실행권한 없음: $REPO_DIR/scaleout/run_scaleout.sh"
fi

# =============================================================================
sec "12. 판정 요약"

[ "$GPU_N" -eq 7 ] && ok "드라이버 GPU 인식 7장 (예상대로)" \
  || { [ "$GPU_N" -eq 8 ] && ok "GPU 8장 전부 복구됨 — deepseek-r1도 가능" \
       || bad "GPU 인식 수 이상: $GPU_N장"; }

[ "$GPU_PCI" -eq "$GPU_N" ] 2>/dev/null && ok "PCIe 열거 수와 드라이버 인식 수 일치" \
  || warn "PCIe($GPU_PCI) vs 드라이버($GPU_N) 불일치 — 3번 섹션 확인"

[ "${FAB_BAD:-1}" -eq 0 ] && ok "전 GPU fabric.status Success" \
  || bad "fabric.status 비정상 GPU 존재 — NVLink P2P 확인 필요 (5번 섹션)"

[ "${SLURM_GRES:-0}" -ge 7 ] && ok "SLURM Gres=gpu:${SLURM_GRES}" \
  || bad "SLURM Gres 부족/미설정 (${SLURM_GRES:-none}) — slurm.conf 수정 필요"

[ "${PYXIS_OK:-0}" -ge 1 ] && ok "pyxis(--container-image) 사용 가능" \
  || bad "pyxis SPANK 플러그인 미인식 — plugstack.conf 확인"

[ "$X7_CFG" -eq 1 ] && ok "B300-SXM-270GBx7 harness config 존재" \
  || bad "B300-SXM-270GBx7/{Offline,Server}/llama2-70b.py 생성 필요 (x8 복사 후 QPS 440->385 / 400->350)"

[ "${SQSH_N:-0}" -ge 1 ] && ok "sqsh 컨테이너 이미지 ${SQSH_N}개 존재" \
  || bad "sqsh 이미지 없음 — make prebuild BENCHMARK=llama ENV=release PREBUILD_TYPE=sqsh 필요"

[ "$L2_READY" -eq 1 ] && ok "llama2-70b 전처리 데이터 준비됨" \
  || bad "llama2-70b 전처리 데이터 없음 — 모델/데이터셋 다운로드 및 preprocess 필요"

[ "${SCRATCH_FREE:-0}" -ge 2000 ] && ok "scratch 여유 ${SCRATCH_FREE}G" \
  || warn "scratch 여유 ${SCRATCH_FREE:-?}G — deepseek-r1까지 하려면 10TB 권장"

echo
echo "########## PASS ##########"; printf '  [OK]   %s\n' "${PASS[@]}" 2>/dev/null
echo "########## WARN ##########"; printf '  [WARN] %s\n' "${WARN[@]}" 2>/dev/null
echo "########## FAIL ##########"; printf '  [FAIL] %s\n' "${FAIL[@]}" 2>/dev/null
echo
echo "FAIL ${#FAIL[@]}건 / WARN ${#WARN[@]}건 / PASS ${#PASS[@]}건"

# =============================================================================
cp /etc/slurm/slurm.conf "$OUT/" 2>/dev/null
cp /etc/slurm/gres.conf "$OUT/" 2>/dev/null
nvidia-smi -q > "$OUT/nvidia-smi-q.txt" 2>&1
dmesg -T > "$OUT/dmesg.txt" 2>&1
lspci -vvv -d 10de: > "$OUT/lspci-nvidia.txt" 2>&1

TAR="/tmp/mlperf-precheck-$(hostname -s)-${TS}.tar.gz"
tar czf "$TAR" -C /tmp "$(basename "$OUT")" 2>/dev/null

echo
echo "============================================================"
echo " 회신할 파일: $TAR"
echo " 크기: $(du -h "$TAR" 2>/dev/null | cut -f1)"
echo "============================================================"
