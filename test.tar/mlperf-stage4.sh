#!/usr/bin/env bash
# =============================================================================
# MLPerf Inference v6.0 Stage4 — llama2-70b 벤치마크 실행 / 결과 판정
# XE9780 / HGX B300 7-GPU
#
#   bash mlperf-stage4.sh test        1분 파이프라인 확인 (먼저 이것부터)
#   bash mlperf-stage4.sh offline     Offline 풀런 (40분)
#   bash mlperf-stage4.sh server      Server 풀런 (30분)
#   bash mlperf-stage4.sh accuracy    Offline AccuracyOnly (ROUGE 검증)
#   bash mlperf-stage4.sh result      실행 없이 최근 결과만 파싱
#   bash mlperf-stage4.sh queue       잡 상태 확인
#
# sbatch로 제출하므로 터미널을 닫아도 계속 돕니다.
# =============================================================================

BASE="${BASE:-/data/lsh}"
REPO_DIR="$BASE/inference_results_v6.0/closed/NVIDIA"
SCRATCH="${MLPERF_SCRATCH_PATH:-$BASE/mlperf_inference_storage}"
SQSH="$REPO_DIR/build/sqsh_images/mlperf-inference-$(whoami)-x86_64-release.sqsh"
NGPU="${NGPU:-7}"
LOGDIR="$BASE/mlperf-runs"; mkdir -p "$LOGDIR"

# 공개값 (NVIDIA DGX B300 8-GPU, v6.0 closed, Tokens/s)
PUB_OFFLINE=112954
PUB_SERVER=107318
TGT_OFFLINE=$(( PUB_OFFLINE * NGPU / 8 ))
TGT_SERVER=$(( PUB_SERVER  * NGPU / 8 ))

MODE="${1:-}"
[ -z "$MODE" ] && { sed -n '4,16p' "$0"; exit 1; }

# =============================================================================
# 결과 파싱
# =============================================================================
parse_result() {
  local d
  d=$(ls -1dt "$REPO_DIR"/build/logs/scaleout_* 2>/dev/null | head -1)
  [ -z "$d" ] && { echo "  실행 로그 디렉토리가 없습니다."; return 1; }
  echo "  로그: $d"

  local sum acc
  sum=$(find "$d" -name mlperf_log_summary.txt 2>/dev/null | head -1)
  acc=$(find "$d" -name mlperf_log_accuracy.json 2>/dev/null | head -1)

  if [ -z "$sum" ]; then
    echo "  mlperf_log_summary.txt 없음 — 아직 실행 중이거나 실패."
    echo "  서버 로그 상태:"
    ls -1 "$d"/slurm_logs/run_llm_server_*.stdout 2>/dev/null | while read -r f; do
      printf "   %-45s %s줄\n" "$(basename "$f")" "$(wc -l < "$f")"
    done
    echo "  최근 에러:"
    grep -hiE 'error|traceback|failed|refused|ZMQ' "$d"/slurm_logs/*.stderr 2>/dev/null | tail -8
    return 1
  fi

  echo
  echo "  ---- LoadGen Summary ----"
  grep -E 'Scenario|Result is|Tokens per second|Completed tokens per second|samples per second|TTFT|TPOT|Min duration satisfied|Min queries satisfied|INVALID' \
       "$sum" | sed 's/^/   /'

  local scen val tps
  scen=$(grep -m1 'Scenario' "$sum" | awk -F': *' '{print $2}')
  val=$(grep -m1 'Result is' "$sum" | awk -F': *' '{print $2}')
  tps=$(grep -m1 -E 'Completed tokens per second|Tokens per second' "$sum" | grep -oE '[0-9]+\.?[0-9]*' | head -1)

  local tgt=0
  case "$scen" in
    *Offline*) tgt=$TGT_OFFLINE ;;
    *Server*)  tgt=$TGT_SERVER ;;
  esac

  echo
  if [ -n "$tps" ] && [ "$tgt" -gt 0 ]; then
    local pct
    pct=$(awk -v a="$tps" -v b="$tgt" 'BEGIN{printf "%.1f", a/b*100}')
    echo "  시나리오 : $scen   판정: ${val:-?}"
    echo "  실측     : $tps Tokens/s"
    echo "  목표     : $tgt Tokens/s  (공개값 x ${NGPU}/8)"
    echo "  달성률   : ${pct}%"
    echo
    awk -v p="$pct" 'BEGIN{
      if (p>=95)      print "  >> 정상. 공개값 스케일 재현 성공.";
      else if (p>=85) print "  >> 다소 낮음. BIOS 전력 프로파일 / throttle 확인 권장.";
      else            print "  >> 유의미하게 낮음. 튜닝 필요 (아래 진단 참고).";
    }'
    RESULT_LINE="V6.L2.${scen}.${tps}tps.${pct}pct.${val}.G${NGPU}"
  else
    echo "  처리량 파싱 실패 — 위 summary 원문 확인"
    RESULT_LINE="V6.L2.PARSE_FAIL.G${NGPU}"
  fi

  if [ -n "$acc" ]; then
    echo
    echo "  ---- Accuracy ----"
    grep -hE 'ROUGE|TOKENS_PER_SAMPLE|PASSED|FAILED' "$d"/*accuracy*.txt "$d"/**/accuracy.txt 2>/dev/null | tail -5 | sed 's/^/   /'
    echo "   (기준: ROUGE1 43.836 / ROUGE2 21.689 / ROUGEL 28.222 / TOKENS_PER_SAMPLE 263.970)"
  fi
}

diagnose() {
  echo
  echo "  ---- 실행 중 수집된 GPU 상태 ----"
  local g="$LOGDIR/gpu-$(date +%Y%m%d).log"
  [ -f "$g" ] && tail -20 "$g" || echo "   (없음)"
}

# =============================================================================
case "$MODE" in
  result)  echo "===== 최근 결과 ====="; parse_result; echo; echo "STATUS: ${RESULT_LINE:-none}"; exit 0 ;;
  queue)   squeue -u "$(whoami)" -o '%.8i %.12P %.20j %.2t %.10M %.6D %R'; exit 0 ;;
esac

# =============================================================================
# 모드별 파라미터
# =============================================================================
case "$MODE" in
  test)     SCEN=Offline; EXTRA="--test_run";                WALL="01:00:00"; NAME=l2-test ;;
  offline)  SCEN=Offline; EXTRA="";                          WALL="02:00:00"; NAME=l2-offline ;;
  server)   SCEN=Server;  EXTRA="";                          WALL="01:30:00"; NAME=l2-server ;;
  accuracy) SCEN=Offline; EXTRA="--test_mode=AccuracyOnly";  WALL="02:00:00"; NAME=l2-acc ;;
  *) echo "알 수 없는 모드: $MODE"; sed -n '4,16p' "$0"; exit 1 ;;
esac

# =============================================================================
# 사전 확인
# =============================================================================
echo "===== 사전 확인 ====="
FATAL=0
chk() { if eval "$2"; then echo "  OK   $1"; else echo "  FAIL $1"; FATAL=1; fi; }
chk "sqsh 이미지"      "[ -f '$SQSH' ]"
chk "x${NGPU} config"  "[ -f '$REPO_DIR/configs/B300-SXM-270GBx${NGPU}/${SCEN}/llama2-70b.py' ]"
chk "전처리 데이터"    "[ -f '$SCRATCH/preprocessed_data/llama2-70b/input_ids_padded.npy' ]"
chk "FP4 체크포인트"   "[ -d '$SCRATCH/models/Llama2/fp4-quantized-modelopt/llama2-70b-chat-hf-torch-fp4' ]"
chk "GPU ${NGPU}장"    "[ \$(nvidia-smi -L | grep -c '^GPU ') -eq $NGPU ]"

BUSY=$(nvidia-smi --query-compute-apps=pid --format=csv,noheader 2>/dev/null | wc -l)
if [ "$BUSY" -gt 0 ]; then
  echo "  경고 GPU에 프로세스 ${BUSY}개 잔존 — 이전 런 잔재일 수 있습니다."
  nvidia-smi --query-compute-apps=pid,used_memory --format=csv | sed 's/^/       /'
fi
[ "$FATAL" -eq 1 ] && { echo; echo "FAIL 항목 해결 후 재실행하세요."; exit 1; }

# =============================================================================
# sbatch 생성 및 제출
# =============================================================================
SB="/tmp/${NAME}.sbatch"
cat > "$SB" <<EOF
#!/bin/bash
#SBATCH --job-name=$NAME
#SBATCH --nodes=1
#SBATCH --gres=gpu:$NGPU
#SBATCH --exclusive
#SBATCH --time=$WALL
#SBATCH --output=$LOGDIR/${NAME}-%j.log

echo "=== \$(date -Is) START $NAME (\$SLURM_JOBID) ==="
nvidia-smi --query-gpu=index,name,memory.used,clocks.sm,power.draw --format=csv

# 백그라운드 텔레메트리 (throttle 추적)
( while true; do
    echo "\$(date +%T) \$(nvidia-smi --query-gpu=index,clocks.sm,power.draw,temperature.gpu,clocks_throttle_reasons.active --format=csv,noheader | tr '\\n' '|')"
    sleep 30
  done ) > $LOGDIR/gpu-\$(date +%Y%m%d).log 2>&1 &
TELE=\$!
trap "kill \$TELE 2>/dev/null" EXIT

cd $REPO_DIR
./scaleout/run_scaleout.sh \\
    --stage all \\
    --atomic-system B300-SXM-270GBx1 \\
    --gpus-per-node $NGPU \\
    --dp-multiplicity $NGPU \\
    --container-image $SQSH \\
    --mlperf-scratch-path $SCRATCH \\
    --extra-srun-flags "--overlap --cpu-bind=none" \\
    --server-spawn-time 20 \\
    --run-args "--benchmarks=llama2-70b --scenarios=$SCEN --core_type=trtllm_endpoint $EXTRA"

echo "=== \$(date -Is) END rc=\$? ==="
EOF

echo
echo "===== 제출 ====="
echo "  모드: $MODE / 시나리오: $SCEN / 제한시간: $WALL"
JID=$(sbatch --parsable "$SB")
echo "  JobID: $JID"
echo "  로그 : $LOGDIR/${NAME}-${JID}.log"
echo
cat <<EOC
--------------------- 모니터링 ---------------------
tail -f $LOGDIR/${NAME}-${JID}.log
bash $0 queue
ls -l $REPO_DIR/build/logs/scaleout_*/slurm_logs/

  서버 ${NGPU}개 기동에 5~10분 (FP4 70B 로딩).
  run_llm_server_dell_gpus{0..$((NGPU-1))}.stdout 이 모두 생겨야 정상.

--------------------- 완료 후 ---------------------
bash $0 result

  목표: Offline $TGT_OFFLINE / Server $TGT_SERVER Tokens/s
EOC
