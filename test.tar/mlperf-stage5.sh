#!/usr/bin/env bash
# =============================================================================
# MLPerf v6.0 Stage5 — trtllm-serve 기동 실패 진단 / 우회
#
#   bash mlperf-stage5.sh diag     서버 로그 증거 수집 (가장 먼저)
#   bash mlperf-stage5.sh serve    래퍼 없이 trtllm-serve 직접 기동 (핵심 판별)
#   bash mlperf-stage5.sh run      우회 옵션 적용해 test_run (1 GPU)
#   bash mlperf-stage5.sh run7     우회 옵션 적용해 test_run (7 GPU)
#   bash mlperf-stage5.sh clean    잔여 잡/프로세스 정리 + 노드 RESUME
#
# 적용하는 우회:
#   1) SLURM_MPI_TYPE=none + --mpi=none   → PMIx 3 vs 5 불일치 회피
#   2) --readiness_timeout=1800           → CUDA 그래프 캡처 시간 확보
#   3) 서버 로그를 화면으로 직접 노출
# =============================================================================

BASE="${BASE:-/data/lsh}"
REPO="$BASE/inference_results_v6.0/closed/NVIDIA"
SCRATCH="${MLPERF_SCRATCH_PATH:-$BASE/mlperf_inference_storage}"
SQSH="$REPO/build/sqsh_images/mlperf-inference-$(whoami)-x86_64-release.sqsh"
MODEL_IN_C="/home/mlperf_inference_storage/models/Llama2/fp4-quantized-modelopt/llama2-70b-chat-hf-torch-fp4"
MOUNTS="$REPO:/work,$SCRATCH:/home/mlperf_inference_storage"

MODE="${1:-}"
[ -z "$MODE" ] && { sed -n '4,12p' "$0"; exit 1; }

newest_log_dir() { ls -1dt "$REPO"/build/logs/scaleout_* 2>/dev/null | head -1; }

# =============================================================================
case "$MODE" in
# -----------------------------------------------------------------------------
diag)
  D=$(newest_log_dir)
  echo "===== 최신 실행 로그 ====="
  echo "$D"
  [ -z "$D" ] && { echo "로그 없음"; exit 1; }
  echo
  echo "--- 디렉토리 내용 ---"
  ls -la "$D"/ | head -20
  echo
  echo "--- 서버 로그 파일 ---"
  ls -la "$D"/trtllm_serve_dp*_rank*.log 2>/dev/null || echo "(없음)"
  echo
  SRV=$(ls -1 "$D"/trtllm_serve_dp0_rank0.log 2>/dev/null | head -1)
  if [ -n "$SRV" ]; then
    echo "===== 핵심 판별 ====="
    echo "OPAL/MPI 에러 건수 : $(grep -c 'OPAL ERROR\|MPI_Init_thread\|Local abort' "$SRV")"
    echo "CUDA graph 캡처    : $(grep -ci 'capturing\|cuda graph\|torch.compile' "$SRV")"
    echo "KV cache 할당      : $(grep -ci 'kv cache\|free_gpu_memory' "$SRV")"
    echo "서버 기동 완료     : $(grep -ci 'Uvicorn running\|Application startup complete\|Started server' "$SRV")"
    echo "OOM / CUDA 에러    : $(grep -ci 'out of memory\|CUDA error\|CUDA_ERROR' "$SRV")"
    echo
    echo "===== 로그 마지막 60줄 ====="
    tail -60 "$SRV"
    echo
    echo "===== 에러 라인만 ====="
    grep -inE 'error|traceback|abort|killed|out of memory|refused|fail' "$SRV" | tail -25
  else
    echo "trtllm_serve_dp0_rank0.log 이 없습니다."
    echo "--- run_llm_server stdout/stderr ---"
    for f in "$D"/slurm_logs/run_llm_server_*; do
      echo "### $f ($(wc -l < "$f" 2>/dev/null)줄)"; tail -15 "$f" 2>/dev/null
    done
  fi
  echo
  echo "===== 현재 GPU / 포트 ====="
  nvidia-smi --query-gpu=index,memory.used,utilization.gpu --format=csv
  ss -tln 2>/dev/null | grep -E '3000[0-9]' || echo "30000번대 LISTEN 없음"
  ;;

# -----------------------------------------------------------------------------
serve)
  echo "===== trtllm-serve 직접 기동 (scaleout 래퍼 우회) ====="
  echo "모델: $MODEL_IN_C"
  echo "이 방식은 trtllm-llmapi-launch(MPI 래퍼)를 거치지 않습니다."
  echo "로그가 화면에 실시간으로 나옵니다. 중단은 Ctrl+C."
  echo "성공 신호: 'Uvicorn running on http://0.0.0.0:30000'"
  echo
  export SLURM_MPI_TYPE=none
  srun --nodes=1 --gres=gpu:1 --time=01:00:00 \
       --overlap --cpu-bind=none --mpi=none \
       --container-image "$SQSH" \
       --container-mounts "$MOUNTS" \
       --container-workdir /work \
       --container-remap-root \
       bash -lc "
         set -x
         nvidia-smi --query-gpu=index,memory.used --format=csv
         ls -la $MODEL_IN_C | head
         trtllm-serve $MODEL_IN_C \
           --host 0.0.0.0 --port 30000 \
           --tp_size 1 --pp_size 1 \
           --max_batch_size 256 \
           --max_num_tokens 4608 \
           --max_seq_len 2048 \
           --backend pytorch
       " 2>&1 | tee "$BASE/trtllm-serve-direct-$(date +%H%M%S).log"
  ;;

# -----------------------------------------------------------------------------
run|run7)
  [ "$MODE" = "run7" ] && NG=7 || NG=1
  echo "===== test_run (${NG} GPU) with 우회 옵션 ====="

  if [ "$NG" -eq 7 ] && [ ! -f "$REPO/configs/B300-SXM-270GBx7/Offline/llama2-70b.py" ]; then
    echo "x7 config 없음. mlperf-precheck-v2.sh --fix 로 먼저 생성하세요."; exit 1
  fi

  export SLURM_MPI_TYPE=none
  cd "$REPO" || exit 1

  CMD=(./scaleout/run_scaleout.sh
       --stage all
       --atomic-system B300-SXM-270GBx1
       --gpus-per-node "$NG"
       --dp-multiplicity "$NG"
       --container-image "$SQSH"
       --mlperf-scratch-path "$SCRATCH"
       --extra-srun-flags "--overlap --cpu-bind=none --mpi=none"
       --server-spawn-time 30
       --run-args "--benchmarks=llama2-70b --scenarios=Offline --core_type=trtllm_endpoint --test_run --readiness_timeout=1800")

  echo "실행 커맨드:"; printf '  %s\n' "${CMD[@]}"; echo

  if [ -n "$SLURM_JOB_ID" ]; then
    echo "기존 allocation $SLURM_JOB_ID 안에서 실행합니다."
    "${CMD[@]}"
  else
    echo "allocation이 없어 salloc으로 감싸 실행합니다."
    salloc --nodes=1 --gres=gpu:"$NG" --exclusive --time=02:00:00 "${CMD[@]}"
  fi

  echo
  echo "===== 결과 확인 ====="
  bash "$0" diag | head -40
  ;;

# -----------------------------------------------------------------------------
clean)
  echo "===== 정리 ====="
  squeue -u "$(whoami)"
  scancel -u "$(whoami)" 2>/dev/null && echo "잡 취소 완료"
  sleep 3
  for p in $(pgrep -f 'trtllm-serve|trtllm-llmapi|code.main' 2>/dev/null); do
    echo "kill $p"; kill -9 "$p" 2>/dev/null
  done
  echo "--- GPU 잔여 프로세스 ---"
  nvidia-smi --query-compute-apps=pid,used_memory --format=csv
  echo "--- 노드 상태 ---"
  sinfo -R
  sinfo
  echo
  echo "노드가 drain이면: sudo scontrol update NodeName=$(hostname -s) State=RESUME"
  ;;

*) echo "알 수 없는 모드: $MODE"; sed -n '4,12p' "$0"; exit 1 ;;
esac
