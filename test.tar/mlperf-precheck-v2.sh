#!/usr/bin/env bash
# =============================================================================
# MLPerf Inference v6.0 사전점검 v2 — XE9780 / HGX B300 (7-GPU degraded)
# 반출 불가 환경용: 결과 파일을 가지고 나올 필요 없음.
#
#   bash mlperf-precheck-v2.sh          점검만 (기본, 시스템 변경 없음)
#   bash mlperf-precheck-v2.sh --fix    x7 config 자동 생성까지
#   bash mlperf-precheck-v2.sh --fix --run   조치 후 1분 test_run까지
#
# 화면에 판정 + 조치 커맨드가 전부 나옵니다.
# 밖으로는 맨 아래 STATUS 한 줄만 받아적어 나오시면 됩니다.
# =============================================================================

REPO_DIR="${REPO_DIR:-/data/lsh/inference_results_v6.0/closed/NVIDIA}"
SCRATCH="${MLPERF_SCRATCH_PATH:-/data/lsh/mlperf_inference_storage}"
PARTITION="${PARTITION:-}"

DO_FIX=0; DO_RUN=0
for a in "$@"; do
  [ "$a" = "--fix" ] && DO_FIX=1
  [ "$a" = "--run" ] && DO_RUN=1
done

DETAIL="/tmp/mlperf-precheck-$(date +%Y%m%d-%H%M%S).log"
d() { { echo "### $*"; eval "$@"; echo; } >> "$DETAIL" 2>&1; }

# 체크 결과 저장: 자리별 P/W/F
declare -A R
declare -A MSG
declare -A FIXCMD
NAMES=(GPU PCI FAB DRV SLU PYX ENR CFG SQSH DATA DISK THR)

set_r() { R[$1]=$2; MSG[$1]=$3; FIXCMD[$1]=${4:-}; }

echo "============================================================"
echo " MLPerf v6.0 사전점검 — $(hostname -s) — $(date '+%F %T')"
echo " 상세로그: $DETAIL"
echo "============================================================"

# ---------- 상세 수집 (화면 출력 없음) ----------
d "uname -a; cat /etc/os-release | head -3"
d "lscpu | grep -Ei 'model name|socket|core|thread|numa'"
d "numactl -H"
d "lspci -d 10de: -nn"
d "lspci -vvv -d 10de:"
d "nvidia-smi"
d "nvidia-smi -q"
d "nvidia-smi topo -m"
d "nvidia-smi nvlink -s"
d "dmesg -T | grep -Ei 'xid|sxid|nvswitch|nvlink' | tail -80"
d "dpkg -l | grep -Ei 'nvidia-open|fabricmanager|nvlink5|nscq|nvsdm|imex|dcgm'"
d "journalctl -u nvidia-fabricmanager --no-pager -n 60"
d "scontrol show node $(hostname -s)"
d "scontrol show config | grep -Ei 'SelectType|GresTypes|MpiDefault|TaskPlugin|ProctrackType'"
d "cat /etc/slurm/slurm.conf /etc/slurm/gres.conf /etc/slurm/cgroup.conf"
d "cat /etc/slurm/plugstack.conf /etc/slurm/plugstack.conf.d/*.conf"
d "enroot version; cat /etc/enroot/enroot.conf | grep -v '^#'"
d "srun --mpi=list"
d "df -h $SCRATCH"

# ---------- 1. GPU 인식 수 ----------
GPU_N=$(nvidia-smi -L 2>/dev/null | grep -c '^GPU ' || echo 0)
if   [ "$GPU_N" -eq 8 ]; then set_r GPU P "GPU 8장 인식 — deepseek-r1(TP8/EP8)도 실행 가능"
elif [ "$GPU_N" -eq 7 ]; then set_r GPU P "GPU 7장 인식 (예상대로) — llama2-70b만 가능, deepseek-r1 불가"
else set_r GPU F "GPU 인식 수 이상: ${GPU_N}장" "nvidia-smi 및 dmesg Xid 확인 → $DETAIL"; fi

# ---------- 2. PCIe 열거 대조 ----------
GPU_PCI=$(lspci -d 10de: -nn 2>/dev/null | grep -Eci '3d controller|display controller' || echo 0)
if [ "$GPU_PCI" -eq "$GPU_N" ]; then set_r PCI P "PCIe 열거($GPU_PCI) = 드라이버 인식($GPU_N) 일치"
else set_r PCI W "PCIe($GPU_PCI) vs 드라이버($GPU_N) 불일치" "lspci -d 10de: -nn 로 누락 슬롯 확인"; fi

# ---------- 3. Fabric 상태 ----------
FAB_TOT=$(nvidia-smi --format=csv,noheader --query-gpu=fabric.status 2>/dev/null | wc -l)
FAB_OK=$(nvidia-smi --format=csv,noheader --query-gpu=fabric.status 2>/dev/null | grep -ci 'success' || echo 0)
if [ "$FAB_TOT" -gt 0 ] && [ "$FAB_OK" -eq "$FAB_TOT" ]; then
  set_r FAB P "fabric.status 전 GPU Success ($FAB_OK/$FAB_TOT) — NVLink P2P 정상"
else
  set_r FAB F "fabric 비정상 ($FAB_OK/$FAB_TOT Success)" \
    "systemctl restart nvidia-fabricmanager; journalctl -u nvidia-fabricmanager -n 60"
fi

# ---------- 4. 드라이버/FM 버전 정합 ----------
DRV=$(nvidia-smi --query-gpu=driver_version --format=csv,noheader 2>/dev/null | head -1)
FMV=$(dpkg -l 2>/dev/null | awk '/nvidia-fabricmanager/{print $3}' | head -1 | cut -d- -f1)
FMACT=$(systemctl is-active nvidia-fabricmanager 2>/dev/null)
if [ "$FMACT" = "active" ] && [ -n "$DRV" ] && [[ "$FMV" == "$DRV"* ]]; then
  set_r DRV P "드라이버 $DRV / FM $FMV 버전 일치, FM active"
elif [ "$FMACT" = "active" ]; then
  set_r DRV W "FM active이나 버전 확인 필요 (드라이버 $DRV / FM ${FMV:-?})" \
    "dpkg -l | grep -E 'nvidia-open|fabricmanager|nvlink5|nscq'"
else
  set_r DRV F "Fabric Manager 비활성 ($FMACT)" "systemctl status nvidia-fabricmanager"
fi

# ---------- 5. SLURM ----------
SGRES=$(scontrol show node "$(hostname -s)" 2>/dev/null | grep -oP 'Gres=gpu:\K[0-9]+' | head -1)
NSTATE=$(sinfo -h -o '%t' -n "$(hostname -s)" 2>/dev/null | head -1)
if [ "${SGRES:-0}" -ge "$GPU_N" ] 2>/dev/null && [ -n "$NSTATE" ]; then
  set_r SLU P "SLURM Gres=gpu:$SGRES, 노드 상태 $NSTATE"
elif [ -n "$SGRES" ]; then
  set_r SLU F "SLURM Gres=gpu:$SGRES < 실제 GPU ${GPU_N}장" \
    "slurm.conf의 Gres=gpu:$GPU_N 및 gres.conf 수정 후 scontrol reconfigure"
else
  set_r SLU F "SLURM Gres 미설정 또는 노드 미인식" "scontrol show node $(hostname -s)"
fi

# ---------- 6. Pyxis ----------
if srun --help 2>&1 | grep -qi 'container-image'; then
  set_r PYX P "pyxis 인식 (--container-image 사용 가능)"
else
  set_r PYX F "pyxis SPANK 플러그인 미인식" \
    "cat /etc/slurm/plugstack.conf → spank_pyxis.so 경로 확인 후 slurmd 재시작"
fi

# ---------- 7. Enroot ----------
ECRED=""
for f in "$HOME/.config/enroot/.credentials" /etc/enroot/.credentials; do
  [ -f "$f" ] && ECRED="$f"
done
EV=$(enroot version 2>/dev/null)
if [ -n "$EV" ] && [ -n "$ECRED" ]; then
  set_r ENR P "enroot $EV, NGC credential 존재 ($ECRED)"
elif [ -n "$EV" ]; then
  set_r ENR W "enroot $EV 이나 NGC credential 없음" \
    "~/.config/enroot/.credentials 에 'machine nvcr.io login \$oauthtoken password <NGC_KEY>' (오프라인이면 sqsh 사전반입)"
else
  set_r ENR F "enroot 미설치/미동작" "enroot version"
fi

# ---------- 8. x7 harness config ----------
C7O="$REPO_DIR/configs/B300-SXM-270GBx7/Offline/llama2-70b.py"
C7S="$REPO_DIR/configs/B300-SXM-270GBx7/Server/llama2-70b.py"
C8="$REPO_DIR/configs/B300-SXM-270GBx8"
if [ -f "$C7O" ] && [ -f "$C7S" ]; then
  set_r CFG P "B300-SXM-270GBx7 config 존재 ($(grep -ho 'expected_qps: [0-9]*\|target_qps: [0-9]*' "$C7O" "$C7S" | tr '\n' ' '))"
elif [ "$DO_FIX" -eq 1 ] && [ -d "$C8" ]; then
  mkdir -p "$REPO_DIR/configs/B300-SXM-270GBx7/Offline" "$REPO_DIR/configs/B300-SXM-270GBx7/Server"
  sed 's/offline_expected_qps: 440/offline_expected_qps: 385/' "$C8/Offline/llama2-70b.py" > "$C7O"
  sed 's/server_target_qps: 400/server_target_qps: 350/'       "$C8/Server/llama2-70b.py"  > "$C7S"
  set_r CFG P "x7 config 자동 생성 완료 (Offline 385 / Server 350)"
else
  set_r CFG F "B300-SXM-270GBx7 config 없음" \
    "이 스크립트를 --fix 로 재실행하거나 수동: x8 복사 후 QPS 440->385, 400->350"
fi

# ---------- 9. sqsh 이미지 ----------
SQSH_N=$(ls -1 "$REPO_DIR/build/sqsh_images/"*.sqsh 2>/dev/null | wc -l)
if [ "$SQSH_N" -ge 1 ]; then
  set_r SQSH P "sqsh 이미지 ${SQSH_N}개: $(ls -1 "$REPO_DIR/build/sqsh_images/"*.sqsh 2>/dev/null | xargs -n1 basename | tr '\n' ' ')"
else
  set_r SQSH F "sqsh 이미지 없음" \
    "salloc 후: cd $REPO_DIR && make prebuild BENCHMARK=llama ENV=release PREBUILD_TYPE=sqsh"
fi

# ---------- 10. 전처리 데이터 ----------
L2="$SCRATCH/preprocessed_data/llama2-70b"
if [ -f "$L2/input_ids_padded.npy" ] && [ -f "$L2/input_lens.npy" ]; then
  set_r DATA P "llama2-70b 전처리 완료 ($(du -sh "$L2" 2>/dev/null | cut -f1))"
else
  set_r DATA F "llama2-70b 전처리 데이터 없음" \
    "OpenOrca pkl 2개 + FP4 체크포인트 반입 후: python3 code/llama2-70b/tensorrt/preprocess_data.py --data_dir build/data/ --preprocessed_data_dir build/preprocessed_data"
fi

# ---------- 11. 디스크 ----------
FREE=$(df -BG --output=avail "$SCRATCH" 2>/dev/null | tail -1 | tr -dc '0-9')
if [ "${FREE:-0}" -ge 2000 ]; then set_r DISK P "scratch 여유 ${FREE}G"
elif [ "${FREE:-0}" -ge 500 ]; then set_r DISK W "scratch 여유 ${FREE}G — llama2만 가능, deepseek-r1은 부족" ""
else set_r DISK F "scratch 여유 ${FREE:-?}G 부족" "10TB 권장"; fi

# ---------- 12. Throttle baseline ----------
THRA=$(nvidia-smi --format=csv,noheader --query-gpu=clocks_throttle_reasons.active 2>/dev/null | sort -u | tr '\n' ' ')
THRHW=$(nvidia-smi -q 2>/dev/null | grep -A8 'Clocks Event Reasons\|Clocks Throttle Reasons' | grep -ci 'HW Slowdown *: Active' || echo 0)
if [ "${THRHW:-0}" -eq 0 ]; then set_r THR P "HW throttle 없음 (idle baseline)"
else set_r THR W "HW slowdown 감지 — 전력/온도 확인" "nvidia-smi -q -d PERFORMANCE"; fi

# =============================================================================
echo
echo "--------------------- 판정 ---------------------"
CODE=""
for k in "${NAMES[@]}"; do
  s="${R[$k]:-F}"; CODE="${CODE}${s}"
  printf ' [%s] %-5s %s\n' "$s" "$k" "${MSG[$k]}"
done

echo
NF=$(echo "$CODE" | tr -cd 'F' | wc -c)
NW=$(echo "$CODE" | tr -cd 'W' | wc -c)

if [ "$NF" -gt 0 ]; then
  echo "--------------------- 조치 커맨드 ---------------------"
  for k in "${NAMES[@]}"; do
    if [ "${R[$k]}" = "F" ] && [ -n "${FIXCMD[$k]}" ]; then
      echo " [$k] ${FIXCMD[$k]}"
    fi
  done
  echo
fi

# ---------- 다음 실행 커맨드 ----------
PART_ARG=""; [ -n "$PARTITION" ] && PART_ARG="--partition=$PARTITION"
echo "--------------------- 본 실행 커맨드 ---------------------"
cat <<EOC
salloc --nodes=1 $PART_ARG --gres=gpu:$GPU_N --exclusive --time=04:00:00

cd $REPO_DIR && ./scaleout/run_scaleout.sh \\
    --stage all --atomic-system B300-SXM-270GBx1 \\
    --gpus-per-node $GPU_N --dp-multiplicity $GPU_N \\
    --mlperf-scratch-path $SCRATCH \\
    --extra-srun-flags "--overlap --cpu-bind=none" \\
    --run-args "--benchmarks=llama2-70b --scenarios=Offline --core_type=trtllm_endpoint"

# 목표: Offline $(( 14119 * GPU_N )) Tokens/s 부근 (공개값 112954 x ${GPU_N}/8)
# 로그: $REPO_DIR/build/logs/scaleout_*/
EOC

# ---------- 옵션: test_run ----------
if [ "$DO_RUN" -eq 1 ] && [ "$NF" -eq 0 ]; then
  echo
  echo "--------------------- 1분 test_run 시작 ---------------------"
  ( cd "$REPO_DIR" && salloc --nodes=1 $PART_ARG --gres=gpu:$GPU_N --exclusive --time=00:40:00 \
    ./scaleout/run_scaleout.sh --stage all --atomic-system B300-SXM-270GBx1 \
      --gpus-per-node "$GPU_N" --dp-multiplicity "$GPU_N" \
      --mlperf-scratch-path "$SCRATCH" \
      --extra-srun-flags "--overlap --cpu-bind=none" \
      --run-args "--benchmarks=llama2-70b --scenarios=Offline --core_type=trtllm_endpoint --test_run" ) 2>&1 | tee -a "$DETAIL"
elif [ "$DO_RUN" -eq 1 ]; then
  echo; echo "FAIL 항목이 있어 test_run을 건너뜁니다."
fi

# =============================================================================
echo
echo "============================================================"
echo " STATUS: V6.${CODE}.G${GPU_N}.D${FREE:-0}G"
echo "         (${NAMES[*]})"
echo " 위 STATUS 한 줄만 받아적어 나오시면 원격 판단 가능합니다."
echo " FAIL ${NF} / WARN ${NW} / PASS $(echo "$CODE" | tr -cd 'P' | wc -c)"
echo " 상세로그(반출 불필요, 현장 참고용): $DETAIL"
echo "============================================================"
